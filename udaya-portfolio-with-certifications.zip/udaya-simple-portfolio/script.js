// You can add simple interactivity here if needed
console.log("Portfolio loaded successfully!");